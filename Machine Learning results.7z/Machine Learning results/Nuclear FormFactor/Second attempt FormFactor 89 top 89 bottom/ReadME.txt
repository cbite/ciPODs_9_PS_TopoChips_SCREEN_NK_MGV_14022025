Metric - Nuclear FormFactor

Top/Bottom surfaces used - 89

Total number of tries = 70

starting the count from 0, 7th best model performed the best with the validation Train acc = 0.79 Test acc = 0.76 Val acc = 0.75  ROC train = 0.89 ROC test = 0.79
			  