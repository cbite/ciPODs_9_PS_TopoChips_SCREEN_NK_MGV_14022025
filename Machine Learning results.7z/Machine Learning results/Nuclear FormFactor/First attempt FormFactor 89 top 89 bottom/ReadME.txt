Metric - Nuclear FormFactor

Top/Bottom surfaces used - 89

Total number of tries = 386

starting the count from 0, 0th best model performed the best with the validation Train acc = 1.0 Test acc = 0.71 Val acc = 0.75  ROC train = 1.00 ROC test = 0.74
			  