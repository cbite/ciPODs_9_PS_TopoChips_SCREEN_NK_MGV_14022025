Metric - Cell count

Top/Bottom surfaces used - 90

Total number of tries = 681

starting the count from 0, 1st best model performed the best with the validation Train acc = 0.82 Test acc = 0.75 Val acc = 0.75  ROC train = 0.90 ROC test = 0.83
			   5th also performed similarly                                    = 0.77          = 0.82         = 0.75            = 0.9           = 0.82
			   6th also performed similarly					   = 0.76          = 0.78         = 0.75            = 0.89          = 0.84 