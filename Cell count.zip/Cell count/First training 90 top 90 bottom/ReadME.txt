Metric - Cell count

Top/Bottom surfaces used - 90

Total number of tries = 1081

starting the count from 0, 3rd best model performed the best with the validation Train acc = 0.79 Test acc = 0.78 Val acc = 0.75  ROC train = 0.91 ROC test = 0.75
			   4th also performed similarly                                    = 0.78          = 0.78         = 0.75            = 0.92            0.75