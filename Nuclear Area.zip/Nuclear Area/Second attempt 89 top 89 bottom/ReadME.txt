Metric - Nuclear area

Top/Bottom surfaces used - 89

Total number of tries = 351

starting the count from 0, 36th best model performed the best with the validation Train acc = 0.83 Test acc = 0.71 Val acc = 0.75  ROC train = 0.92 ROC test = 0.74
			 